<?php
require "includes/startses_con.inc.php";
?>
<main>
    <div class="wrapper-main">
        <section class="section-default">
            <h1>Signup</h1>
        </section>
    </div>
</main>

