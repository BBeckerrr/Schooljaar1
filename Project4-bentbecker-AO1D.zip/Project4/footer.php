<?php
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Itaxi</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="assets/css/main.css" />
    </head>
    <!-- Footer -->
    <footer id="footer">
        <div class="copyright">
            &copy; Design by: Bent, Krijn en Jason.
        </div>
    </footer>
</html>
