<?php
    require "header.php";
?>
<!DOCTYPE HTML>
<html>
		<!-- Banner -->
			<section id="banner">
				<div class="content">
					<h1>Itaxi <br> Het is beter dan lopen!</h1>
					<ul class="actions">
						<li><a href="contact.php" class="button scrolly">Neem contact op</a></li>
					</ul>
				</div>
			</section>

		<!-- wrapper -->
			<section id="1" class="wrapper style1 special">
				<div class="inner">
					<h2>Ons concept</h2>
					<figure>
					    <p>
							Vivamus venenatis fermentum bibendum. Mauris id feugiat dui. Nulla non felis sodales, accumsan erat eu, lobortis libero. Aenean iaculis sodales augue sed dapibus. Suspendisse dictum nisi ac urna imperdiet, non placerat odio ultricies. Donec et urna vel libero tempus viverra ullamcorper at nisl. Vivamus sit amet malesuada dui. Nullam finibus dictum sapien, ac varius nisi accumsan in. Suspendisse feugiat, neque eu aliquet viverra, eros lectus iaculis ipsum, non scelerisque justo quam at erat. Aliquam sodales urna viverra, pretium nunc sagittis, molestie leo. Proin efficitur dolor vel accumsan consectetur. Maecenas fermentum auctor ex, a tempor diam consectetur ut. Suspendisse ac sapien laoreet, lacinia mi id, viverra tortor. Mauris eleifend, tortor sed elementum venenatis, lacus magna tristique purus, nec placerat dui libero quis ante. </p>
					</figure>
				</div>
			</section>
        <?php
        require "footer.php";
        ?>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>