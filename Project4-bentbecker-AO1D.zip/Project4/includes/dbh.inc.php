<?php
$dBServername = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "ixat";

// Connectie
$conn = mysqli_connect($dBServername, $dBUsername, $dBPassword, $dBName);

// error
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
