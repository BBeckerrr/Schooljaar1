<?php
require "header.php";
?>

<!DOCTYPE HTML>
<html>
<head>
    <style>
        /* Set the size of the div element that contains the map */
        #map {
            height: 400px;  /* The height is 400 pixels */
            width: 100%;  /* The width is the width of the web page */
        }
    </style>
    <title>Itaxi</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/main.css" />
</head>
<!-- Main -->
<section id="main" class="wrapper">
    <div class="inner">

        <!-- Content -->
        <?php
        if (!isset($_SESSION['id'])) {
            echo '<h2 id = "content" > Login! </h2>';

        }
        ?>

        <!-- Form -->
            <?php
            if (isset($_SESSION['id'])) {
                echo '<h2 id = "content"> Welkom op uw profiel  ';
                echo $_SESSION['uid'];
                echo '</h2>';

            }
            if (isset($_SESSION['rijbewijs'])){
                echo '<h2 id = "content"> U Bent Chauffeur ';
            }
            if(isset($_SESSION['rijbewijzen'])){
                echo '<h2 id = "content"> U Bent Chauffeur ';
            }
            ?>

        <br>
        <br>
        <?php
if (isset($_POST['Submitstemmen'])) {

    $query = "UPDATE users SET locatie_A = ?,locatie_B = ?, tijd = ?, personen  = ? WHERE idUsers = ?";
    $stmt = mysqli_prepare($conn, $query);

    mysqli_stmt_bind_param($stmt, "sssss", $stem, $locatie_b, $tijd, $personen,  $id);

    $stem = $_POST['stem'];
    $locatie_b = $_POST['locatieb'];
    $tijd = $_POST['tijd'];
    $personen = $_POST['personen'];
    $id = $_SESSION['id'];

    /* Execute the statement */
    mysqli_stmt_execute($stmt);
}

if(isset($stem))
    echo "<p class='text-center'>U rit is aangevraagd!<br> van $stem naar $locatie_b met $personen personen om $tijd</p>";

if (!isset($_SESSION['id'])) {
    echo '<p class="logout-status">U moet inloggen een aanvraag te doen.<br>
            Maak <a href="signup.php">hier</a> een account aan</p><br>';
}
else if (isset($_SESSION['id'])) {
    echo '<div class="custom-select text-center center-this" style="width:500px;"><form method="post"  action="" id="stemmen">
            <label for="Stem">Plan een rit!</label><br>
            <h5>van</h5>
                <input type="text" name="stem" id="stem" placeholder="dorp/stad straat huisnummer" required>
                <h5>naar</h5>
                <input type="text" name="locatieb" id="locatieb" placeholder="dorp/stad straat huisnummer" required>
                <input type="time" id="tijd" name="tijd" placeholder="0000" required>
                <input type="number" name="personen" id="personen" placeholder="Personen" required>
                <input type="button" class="button" onclick="GetDirections()" value="Route" />
            <Button class="button" type="submit" onclick="GetDirections()" name="Submitstemmen">Verzoek indienen!</Button>
    </form></div>';
}
else{
 $result = mysql_query("SELECT * FROM users WHERE idUsers = '$id' AND locatie_A = '$stem'");
  $count = mysql_num_rows($result);
  if($count > 0){
  echo "<p>U heeft al een rit!</p>";
 }
}
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title></title>
            <meta charset="utf-8" />
            <script type='text/javascript'>
                var map, directionsManager;

                function GetMap()
                {
                    map = new Microsoft.Maps.Map('#myMap', {});

                    //Load the directions module.
                    Microsoft.Maps.loadModule('Microsoft.Maps.Directions', function () {
                        //Create an instance of the directions manager.
                        directionsManager = new Microsoft.Maps.Directions.DirectionsManager(map);

                        //Specify where to display the route instructions.
                        directionsManager.setRenderOptions({ itineraryContainer: '#directionsItinerary' });

                        //Specify the where to display the input panel
                        directionsManager.showInputPanel('directionsPanel');
                    });
                }

                function GetDirections() {
                    //Clear any previously calculated directions.
                    directionsManager.clearAll();
                    directionsManager.clearDisplay();

                    //Create waypoints to route between.
                    var start = new Microsoft.Maps.Directions.Waypoint({ address: document.getElementById('stem').value });
                    directionsManager.addWaypoint(start);

                    var end = new Microsoft.Maps.Directions.Waypoint({ address: document.getElementById('locatieb').value });
                    directionsManager.addWaypoint(end);

                    //Calculate directions.
                    directionsManager.calculateDirections();
                }
            </script>
            <script type='text/javascript' src='https://www.bing.com/api/maps/mapcontrol?callback=GetMap&key=Akw-8gYrGihn5s0yDthXZ6BTQA1-_jUoaKP2KB_FmEpM5fBKgQVhskY2-3ZJulEQ' async defer></script>
        </head>
        <body>
        <div id="myMap" style="position:relative;width:800px;height:600px;"></div>
        </body>
        </html>

        </h2>
        <!-- Content -->
        <h2 id="content">Aanpassen van uw gegevens</h2>
        <p>Praesent ac adipiscing ullamcorper semper ut amet ac risus. Lorem sapien ut odio odio nunc. Ac adipiscing nibh porttitor
            erat risus justo adipiscing adipiscing amet placerat accumsan. Vis. Faucibus odio magna tempus adipiscing a non. In mi primis arcu u
            t non accumsan vivamus ac blandit adipiscing adipiscing arcu metus praesent turpis eu ac lacinia nunc ac commodo gravida adipiscing eget accumsan ac
            nunc adipiscing adipiscing.</p>
    </div>
</section>
<?php
require "footer.php";
?>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.scrolly.min.js"></script>
<script src="assets/js/skel.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>

</body>
</html>
