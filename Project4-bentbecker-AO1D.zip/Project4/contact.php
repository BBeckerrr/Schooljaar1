<?php
require "header.php";
?>
<html>
<head>
    <title>Generic - Intensify by TEMPLATED</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/main.css" />
</head>
<body class="subpage">

<!-- Header -->
<div class="12u">
    <section id="main" class="wrapper">
        <div class="inner">
            <header class="align-center">
                <h1>Contact Pagina</h1>
            </header>
            <!-- Content -->
            <h2 id="content">Over ons</h2>
            <p>Praesent ac adipiscing ullamcorper semper ut amet ac risus. Lorem sapien ut odio odio nunc. Ac adipiscing nibh porttitor
                erat risus justo adipiscing adipiscing amet placerat accumsan. Vis. Faucibus odio magna tempus adipiscing a non. In mi primis arcu u
                t non accumsan vivamus ac blandit adipiscing adipiscing arcu metus praesent turpis eu ac lacinia nunc ac commodo gravida adipiscing eget accumsan ac
                nunc adipiscing adipiscing.</p>

            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d19827.49275324168!2d5.593672592925387!3d51.5968884823516!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c71e4d6384b88b%3A0x8c5ca7b79658e1d5!2sErp!5e0!3m2!1snl!2snl!4v1593115002805!5m2!1snl!2snl"
                    width="1200" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            <br>
            <br>
            <br>
            <!-- Form -->
            <h2 id="content"> Vragen? stuur ze hier!</h2>
            <form class="form-signup" action="includes/#" method="post">
                <input type="text" name="naam" placeholder="Naam">
                <input type="email" name="email" placeholder="E-Mail">
                <div class="12u$">
                    <textarea name="message" id="message" placeholder="Plaats hier je bericht" rows="6"></textarea>
                </div>
                <button type="submit" name="signupC-submit">Verzend</button>
            </form>
        </div>
    </section>
</body>

<!-- Footer -->
<?php
require "footer.php";
?>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.scrolly.min.js"></script>
<script src="assets/js/skel.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>

</body>
</html>
