<?php
require "header.php";
?>
<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/html">
	<head>
		<title>Itaxi</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
		<!-- Main -->
    <div class="12u">
        <section id="main" class="wrapper">
            <div class="inner">
                <header class="align-center">
                    <h1>Chauffeurs pagina</h1>
                </header>
                <div class="header-login">
                    <?php
                    if (!isset($_SESSION['id'])) {
                        echo '<h1>login in of registreer</h1>
           <form action="includes/loginchauf.inc.php" class="left" method="post">
            <input class="left" type="text" name="mailuid" placeholder="E-mail/Username">
            <input class="left" type="password" name="pwd" placeholder="Password">
            <button type="submit" class="button special" name="login-submit">Login</button>
          </form>';
                    }
                    else if (isset($_SESSION['id'])) {
                        echo '<form action="includes/logout.inc.php" method="post">
          </form>
          <nav class="align">
          </nav>';
                    }
                    ?>
                    <?php
                    if (!isset($_SESSION['automerk'])){
                       echo '<h1>U Bent een klant en geen chauffeur ga naar de klant pagina.</h1><br><br><br>';
                    }
                    ?>
                </div>
					<!-- Content -->
						<h2 id="content">Chauffeursreglement</h2>
						<p>Praesent ac adipiscing ullamcorper semper ut amet ac risus. Lorem sapien ut odio odio nunc. Ac adipiscing nibh porttitor
                            erat risus justo adipiscing adipiscing amet placerat accumsan. Vis. Faucibus odio magna tempus adipiscing a non. In mi primis arcu u
                            t non accumsan vivamus ac blandit adipiscing adipiscing arcu metus praesent turpis eu ac lacinia nunc ac commodo gravida adipiscing eget accumsan ac
                            nunc adipiscing adipiscing.</p>
                <?php
                if (!isset($_SESSION['automerk'])){
                    echo '<br><br><br><br><br><br><br><br>';
                }
                ?>
								<!-- Form -->
                <?php
                // Errormessage voor als er een fout word gemaakt.
                if (isset($_GET["error"])) {
                    if ($_GET["error"] == "emptyfields") {
                        echo '<p class="signuperror">Vul alle velden in!</p>';
                    }
                    else if ($_GET["error"] == "invaliduidmail") {
                        echo '<p class="signuperror">Invalid naam of email!</p>';
                    }
                    else if ($_GET["error"] == "invaliduid") {
                        echo '<p class="signuperror">Invalid naam!</p>';
                    }
                    else if ($_GET["error"] == "invalidmail") {
                        echo '<p class="signuperror">Invalid e-mail!</p>';
                    }
                    else if ($_GET["error"] == "passwordcheck") {
                        echo '<p class="signuperror">De wachtwoorden komen niet overeen.</p>';
                    }
                    else if ($_GET["error"] == "usertaken") {
                        echo '<p class="signuperror">Deze gebruikersnaam is al ingebruik.</p>';
                    }
                }
                // voor als het wel lukt
                else if (isset($_GET["signup"])) {
                    if ($_GET["signup"] == "success") {
                        echo '<p class="signupsuccess">Aanmelding voltooid!</p>';
                    }
                }
                ?>
                <?php
                if (!isset($_SESSION['id'])) {
                    echo '<form class="form-signup" action="includes/chauffeurs.inc.php" method="post">';
                    //checken voor dubbele email en accounts
                    if (!empty($_GET["uid"])) {
                        echo '<input type="text" name="uid" placeholder="Username" value="' . $_GET["uid"] . '">';
                    } else {
                        echo '<input type="text" name="uid" placeholder="Gebruikersnaam">';
                    }
                    if (!empty($_GET["mail"])) {
                        echo '<input type="text" name="mail" placeholder="E-mail" value="' . $_GET["mail"] . '">';
                    } else {
                        echo '<input type="text" name="mail" placeholder="E-mail">';
                    }

                    echo '<input type="password" name="pwd" placeholder="Password">
                <input type="password" name="pwd-repeat" placeholder="Repeat password">
                <input type="tel" name="mobiel_nmr" placeholder="Mobiel Nummer">
                <input type="text" name="rijbewijzen" size="1" maxlength="1" minlength="1" placeholder="Rijbewijzen">
                <input type="text" name="automerk" placeholder="merk auto">
                <input type="text" name="typeauto" placeholder="type auto">
                <input type="text" name="Kenteken" placeholder="Kenteken">
                <input type="number" name="passagiers" placeholder="Aantal passagiers">
                <input type="number" name="laadruimte" placeholder="laadruimte (in Liters)">
                <input type="number" name="schadevrijejaren" placeholder="schade vrije jaren">
                <input type="text" name="Naam" placeholder="naam">
                <button type="submit" name="signupC-submit">Signup</button>
                </form>';
                }

                if (isset($_POST['Submitstemmen'])) {

                    $query = "UPDATE chauffeurs SET emailUsers = ?, MobielNr WHERE idUsers = ?";
                    $stmt = mysqli_prepare($conn, $query);

                    mysqli_stmt_bind_param($stmt, "ss", $email, $mobiel);

                    $username = $_POST['uid'];
                    $email = $_POST['mail'];
                    $mobiel= $_POST['mobiel_nmr'];
                    $rijbewijzen = $_POST['rijbewijzen'];
                    $automerk = $_POST['automerk'];
                    $typeauto = $_POST['typeauto'];
                    $kenteken = $_POST['Kenteken'];
                    $passagiers = $_POST['passagiers'];
                    $laadruimte = $_POST['laadruimte'];
                    $schadejaren = $_POST['schadevrijejaren'];
                    $naam = $_POST['Naam'];

                    /* Execute the statement */
                    mysqli_stmt_execute($stmt);
                }

                if (isset($stem))
                    echo "<p class='text-center'>U rit is aangevraagd!<br></p>";

                if (!isset($_SESSION['id'])) {
                    echo '';
                } else if (isset($_SESSION['automerk'])) {
                    echo '<div class="custom-select text-center center-this" style="width:500px;"><form method="post"  action="" id="stemmen">'
                        ?>
                <h4>gebruikersnaam</h4>
                <input type="text" id="uid" name="uid" placeholder="<?php echo $_SESSION['uid']; ?>">
                <h4>E-Mail</h4>
                <input type="text" id="mail"  name="mail" placeholder="<?php echo $_SESSION['email']; ?>">
                <h4>mobiel nummer</h4>
                <input type="text" id="mobiel_nmr"  name="mobiel_nmr" placeholder="<?php echo $_SESSION['mobiel']; ?>">
                <h4>rijbewijs</h4>
                <input type="text" id="rijbewijzen"  name="rijbewijzen" size="1" maxlength="1" minlength="1" placeholder="<?php echo $_SESSION['rijbewijs']; ?>">
                <h4>automerk</h4>
                <input type="text" id="automerk"  name="automerk" placeholder="<?php echo $_SESSION['automerk']; ?>">
                <h4>type auto</h4>
                <input type="text" id="typeauto"  name="typeauto" placeholder="<?php echo $_SESSION['typeauto']; ?>">
                <h4>kenteken</h4>
                <input type="text" id="Kenteken"  name="Kenteken" placeholder="<?php echo $_SESSION['kenteken']; ?>">
                <h4>aantal zitplekken voor passagiers</h4>
                <input type="number" id="passagiers"  name="passagiers" placeholder="<?php echo $_SESSION['passagiers']; ?>">
                <h4>laadruimte (in liters)</h4>
                <input type="number" id="laadruimte"  name="laadruimte" placeholder="<?php echo $_SESSION['laadruimte']; ?>">
                <h4>aantal schadejaren</h4>
                <input type="number" id="schadevrijejaren"  name="schadevrijejaren" placeholder="<?php echo $_SESSION['schadejaren']; ?>">
                <h4>naam</h4>
                <input type="text" id="Naam"  name="Naam" placeholder="<?php echo $_SESSION['naam']; ?>">
            <Button class="button" type="submit" onclick="GetDirections()" name="Submitstemmen">Verzoek indienen!</Button>
    </form></div>
            <?php
                } else {
                    $result = mysql_query("SELECT * FROM users WHERE idUsers = '$username' AND locatie_A = '$stem'");
                    $count = mysql_num_rows($result);
                    if ($count > 0) {
                        echo "<p>U heeft al een rit!</p>";
                    }
                }

                ?>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
            </div>
</section
</html>
</html>
<?php
 require "footer.php";
?>
